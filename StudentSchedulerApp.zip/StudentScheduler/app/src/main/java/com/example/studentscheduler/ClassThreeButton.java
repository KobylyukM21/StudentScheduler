package com.example.studentscheduler;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ClassThreeButton extends AppCompatActivity {
    private EditText assignmentEditText;
    private EditText classNameEditText;
    private ListView listView;
    private ArrayAdapter<String> adapter;
    private List<String> assignmentList3 = new ArrayList<>();
    private int selectedIndex = -1;
    private static final String SHARED_PREFS_KEY3 = "com.example.studentscheduler.assignments3";
    private static final String ASSIGNMENT_KEY3 = "assignments3";
    private static final String CLASS_NAME_KEY = "class_name";
    private static final String CHANNEL_ID = "notification_channel";
    private static final int NOTIFICATION_ID = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.classthreepage);

        assignmentEditText = findViewById(R.id.assignment1);
        classNameEditText = findViewById(R.id.class_name);
        listView = findViewById(R.id.list_view);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, assignmentList3);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (selectedIndex != position) {
                    view.setBackgroundColor(Color.LTGRAY);
                    if (selectedIndex != -1) {
                        parent.getChildAt(selectedIndex).setBackgroundColor(Color.TRANSPARENT);
                    }
                    selectedIndex = position;
                }
            }
        });

        loadAssignments3();
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveAssignments3();
    }

    public void submitAssignment(View view) {
        String assignment = assignmentEditText.getText().toString();
        assignmentList3.add(assignment);
        adapter.notifyDataSetChanged();
        assignmentEditText.setText("");
        saveAssignments3();

        createNotificationChannel();
        sendNotification(assignment);
    }

    public void removeAssignment(View view) {
        if (selectedIndex != -1) {
            assignmentList3.remove(selectedIndex);
            adapter.notifyDataSetChanged();
            selectedIndex = -1;
            saveAssignments3();
        }
    }

    private void loadAssignments3() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS_KEY3, Context.MODE_PRIVATE);
        String className = sharedPreferences.getString(CLASS_NAME_KEY, "");
        classNameEditText.setText(className);
        String assignments = sharedPreferences.getString(ASSIGNMENT_KEY3, "");
        if (!assignments.isEmpty()) {
            assignmentList3.clear();
            assignmentList3.addAll(Arrays.asList(assignments.split("\n")));
            adapter.notifyDataSetChanged();
        }
    }

    private void saveAssignments3() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS_KEY3, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(CLASS_NAME_KEY, classNameEditText.getText().toString());
        StringBuilder builder = new StringBuilder();
        for (String assignment : assignmentList3) {
            builder.append(assignment).append("\n");
        }
        editor.putString(ASSIGNMENT_KEY3, builder.toString());
        editor.apply();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            String channelName = "My Channel";
            String channelDescription = "My Channel Description";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, channelName, importance);
            channel.setDescription(channelDescription);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    private void sendNotification(String assignment) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle("New Assignment Added To Class 3")
                .setContentText(assignment)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        notificationManager.notify(0, builder.build());
    }
}

