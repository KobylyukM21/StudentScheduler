package com.example.studentscheduler;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class HomePageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.homepage);

        Button classOneButton = findViewById(R.id.class1);
        classOneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomePageActivity.this, ClassOneButton.class);
                startActivity(intent);
            }
        });

        Button classTwoButton = findViewById(R.id.class2);
        classTwoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomePageActivity.this, ClassTwoButton.class);
                startActivity(intent);
            }
        });

        Button classThreeButton = findViewById(R.id.class3);
        classThreeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomePageActivity.this, ClassThreeButton.class);
                startActivity(intent);
            }
        });

        Button classFourButton = findViewById(R.id.class4);
        classFourButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomePageActivity.this, ClassFourButton.class);
                startActivity(intent);
            }
        });
    }
}
