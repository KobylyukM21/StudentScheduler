package com.example.studentscheduler;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ClassOneButton extends AppCompatActivity {

    private EditText assignmentEditText;
    private EditText classButtonEditText;
    private ListView listView;
    private ArrayAdapter<String> adapter;
    private List<String> assignmentList = new ArrayList<>();
    private int selectedIndex = -1;
    private static final String SHARED_PREFS_KEY = "com.example.studentscheduler.assignments";
    private static final String ASSIGNMENT_KEY = "assignments";
    private static final String CLASS_BUTTON_KEY = "class_button";
    private static final String CHANNEL_ID = "MyChannelId";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.classonepage);

        // create the notification channel
        createNotificationChannel();

        assignmentEditText = findViewById(R.id.assignment1);
        classButtonEditText = findViewById(R.id.classbutton);
        listView = findViewById(R.id.list_view);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, assignmentList);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (selectedIndex != position) {
                    view.setBackgroundColor(Color.LTGRAY);
                    if (selectedIndex != -1) {
                        parent.getChildAt(selectedIndex).setBackgroundColor(Color.TRANSPARENT);
                    }
                    selectedIndex = position;
                }
            }
        });

        loadAssignments();
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveAssignments();
    }

    public void submitAssignment(View view) {
        String assignment = assignmentEditText.getText().toString();
        assignmentList.add(assignment);
        adapter.notifyDataSetChanged();
        assignmentEditText.setText("");
        saveAssignments();
        sendNotification(assignment);
    }

    public void removeAssignment(View view) {
        if (selectedIndex != -1) {
            assignmentList.remove(selectedIndex);
            adapter.notifyDataSetChanged();
            selectedIndex = -1;
            saveAssignments();
        }
    }

    private void loadAssignments() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS_KEY, Context.MODE_PRIVATE);
        String assignments = sharedPreferences.getString(ASSIGNMENT_KEY, "");
        String classButton = sharedPreferences.getString(CLASS_BUTTON_KEY, "");

        if (!assignments.isEmpty()) {
            assignmentList.addAll(Arrays.asList(assignments.split("\n")));
            adapter.notifyDataSetChanged();
        }

        classButtonEditText.setText(classButton);
    }

    private void saveAssignments() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS_KEY, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        StringBuilder sb = new StringBuilder();
        for (String s : assignmentList) {
            sb.append(s).append("\n");
        }
        editor.putString(ASSIGNMENT_KEY, sb.toString());
        editor.putString(CLASS_BUTTON_KEY, classButtonEditText.getText().toString());
        editor.apply();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            String channelName = "My Channel";
            String channelDescription = "My Channel Description";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, channelName, importance);
            channel.setDescription(channelDescription);

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    private void sendNotification(String assignment) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle("New Assignment Added To Class 1")
                .setContentText(assignment)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        notificationManager.notify(0, builder.build());
    }
}
